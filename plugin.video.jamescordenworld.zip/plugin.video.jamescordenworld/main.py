import sys
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

VIDEOS = {'Carpool': [{'name': 'Adele',
                       'thumb': 'http://hbz.h-cdn.co/assets/16/02/980x490/landscape-1452990025-gettyimages-505108136.jpg',
                       'video': 'https://cldup.com/22ssa5ST9N.webm',
                       'genre': 'Carpool'},
                      {'name': '1 Direction',
                       'thumb': 'http://cbsnews1.cbsistatic.com/hub/i/r/2015/12/16/f5d3bd6b-516c-402c-94b7-6eabfa993339/thumbnail/620x350/838c85ca7c521618aeac4b767dd4a53d/corden.jpg',
                       'video': 'https://cldup.com/Jf8pi08Rxt.webm',
                       'genre': 'Carpool'},
                      {'name': 'Elton John',
                       'thumb': 'http://cdn.unilad.co.uk/wp-content/uploads/2016/02/elton3.jpg',
                       'video': 'https://cldup.com/sJrC55uTH8.webm',
                       'genre': 'Carpool'}
                      ],
		'Lesbian Vampire Killers': [{'name': 'Link 1',
                       'thumb': 'http://nightflight.com/wp-content/uploads/LESBIAN-1.jpg',
                       'video': 'http://188.240.220.152/i5jhpwuiluqwws4phwhtq7ov4o3qkcv2ucxpvadttau2mdp63tgtexyrsiqa/Lesbian Vampire Killers_5B2009_5DDvDrip-aXXo.avi',
                       'genre': 'Lesbian Vampire Killers'},
                      {'name': 'Link 2',
                       'thumb': 'http://nightflight.com/wp-content/uploads/LESBIAN-1.jpg',
                       'video': 'http://50.7.164.218:8182/s2oqyxlj5gu4tqukwy5lnslccjfthdn5jkrdivakxsgujdpwnyxc5c7b6q/7g80zhnr5qpj.mp4',
                       'genre': 'Lesbian Vampire Killers'}
                      ],				 
		'Into the Woods': [{'name': 'Link 1',
                       'thumb': 'http://www.frolichawaii.com/wp-content/uploads/2014/12/woodsposter.jpg',
                       'video': 'http://77.81.98.13/p5jhpifuk4qwws4phxctqmelxo4rbipz2gjkr6znda4myu3if67oocxekokq/Into the Woods (2014) BDRip.mkv',
                       'genre': 'Into the Woods'}
                      ],
					  		'Kill Your Friends': [{'name': 'Link 1',
                       'thumb': 'http://www.screenrelish.com/wp-content/uploads/2015/09/KILL-YOUR-FRIENDS-INTL-POSTER.jpg',
                       'video': 'http://198.16.68.242/ebjhp6kajqqwws4phwrtwzuc75q46iv7mlwhjx4265btenbw5ijk4nndmnvq/Kill.Your.Friends.2015.BRRip.XviD.AC3-EVO.mp4',
                       'genre': 'Kill Your Friends'}
                      ],
					  		'Whatever Happened to Harold Smith': [{'name': 'Link 1',
                       'thumb': 'http://www.moviepostercompany.co.uk/wordpress/wp-content/uploads/P3041574.jpg',
                       'video': 'http://50.7.164.210:8182/q6orkowf7wu4tqukwzwlnflscpynr2ixwallemnksas3dpjrq6oolrm3di/video.flv',
                       'genre': 'Whatever Happened to Harold Smith'}
                      ],
					   		'All or Nothing': [{'name': 'Link 1',
                       'thumb': 'https://s-media-cache-ak0.pinimg.com/736x/37/28/8e/37288e0e5e0f94a46174b5a7381736cc.jpg',
                       'video': 'http://n80.stagevu.com/v/b07e47514d0502ed4d4153d6a0091057/192553.avi',
                       'genre': 'All or Nothing'}
					  ],
					  		'The History Boys': [{'name': 'Link 1',
                       'thumb': 'http://benwoolf.co.uk/wp-content/uploads/2014/04/dominic_cooper_in_the_history_boys_wallpaper_1_1024.jpg',
                       'video': 'http://188.240.220.156/ivjhplnwkmqwws4phvtdw3otxi5xldasgkpjndvwu55gfigkyez4grby6wca/The.History.Boys.2006.DVDRip.x264-HANDJOB.mkv',
                       'genre': 'The History Boys'}
					  ],
					  		'Planet 51': [{'name': 'Link 1',
                       'thumb': 'http://musingsfromus.com/wp-content/uploads/2012/01/Planet-51-2009-DVD-Cover.jpg',
                       'video': 'http://95.211.191.16/ofjhob4woyqwws4phxddsneg5pyvv3gppdboswrbakkwdacki4junij6vi3a/Planet_51_2009___720p_x264_-MgB.mp4',
                       'genre': 'Planet 51'}
					  ],
            'Gavin and Stacey Series 1': [{'name': 'Episode 1',
                      'thumb': 'http://img.thesun.co.uk/aidemitlum/archive/00787/00-02_22mg__3__682_787981a.jpg',
                      'video': 'http://50.7.164.218:8182/4sor4pdj5su4tqukwzdlnczulzi3mibarnx2jqxyjhja4oq3bvjg3kc5sy/video.flv',
                      'genre': 'Gavin and Stacey Series 1'},
                     {'name': 'Episode 2',
                      'thumb': 'http://img.thesun.co.uk/aidemitlum/archive/00787/00-02_22mg__3__682_787981a.jpg',
                      'video': 'http://50.7.164.186:8182/lsor4mtj5su4tqukwzdlnslelinwlvxcon3n4nixphk5s7s3qt33bufo2u/video.flv',
                      'genre': 'Gavin and Stacey Series 1'},
                     {'name': 'Episode 3',
                      'thumb': 'http://img.thesun.co.uk/aidemitlum/archive/00787/00-02_22mg__3__682_787981a.jpg',
                      'video': 'http://50.7.164.234:8182/osorun3j5su4tqukwzdlnclrjdklsonpmthcmr65pngg7h6hiabaunh25u/video.flv',
                      'genre': 'Gavin and Stacey Series 1'},
					                       {'name': 'Episode 4',
                      'thumb': 'http://img.thesun.co.uk/aidemitlum/archive/00787/00-02_22mg__3__682_787981a.jpg',
                      'video': 'http://50.7.164.234:8182/pcor4ntj5su4tqukwzdlnctikohg7ghu2xjn5qwrpotldz73hrxchpxzxu/video.flv',
                      'genre': 'Gavin and Stacey Series 1'},
					                       {'name': 'Episode 5',
                      'thumb': 'http://img.thesun.co.uk/aidemitlum/archive/00787/00-02_22mg__3__682_787981a.jpg',
                      'video': 'http://50.7.164.234:8182/okorik3j5su4tqukwzdlngz4lybo35xyrenywsli3ksxgqcov5nuctqkf4/video.flv',
                      'genre': 'Gavin and Stacey Series 1'},
					                       {'name': 'Episode 6',
                      'thumb': 'http://img.thesun.co.uk/aidemitlum/archive/00787/00-02_22mg__3__682_787981a.jpg',
                      'video': 'http://50.7.164.234:8182/ngoq6klj5su4tqukwzdlnbdakdngykmrqzyt2u3v4tlkj5lujojzsafbky/video.flv',
                      'genre': 'Gavin and Stacey Series 1'}
                     ],
            'Gavin and Stacey Series 2': [{'name': 'Episode 1',
                      'thumb': 'http://cdn1.ssninsider.com/wp-content/uploads/2013/02/Gavin-And-Stacey-Series-2.jpg',
                      'video': 'http://50.7.164.202:8182/v2orikdj5su4tqukwzdlnd3lipvq6wt4vz7o6h7wbxrn7plpl74connixi/video.flv',
                      'genre': 'Gavin and Stacey Series 2'},
                     {'name': 'Episode 2',
                      'thumb': 'http://cdn1.ssninsider.com/wp-content/uploads/2013/02/Gavin-And-Stacey-Series-2.jpg',
                      'video': 'http://50.7.164.250:8182/ecobiltj5su4tqukwzdlnrt7jb63fga3ydjeqyvazef4ysaohdvkz7rauu/video.flv',
                      'genre': 'Gavin and Stacey Series 2'},
                     {'name': 'Episode 3',
                      'thumb': 'http://cdn1.ssninsider.com/wp-content/uploads/2013/02/Gavin-And-Stacey-Series-2.jpg',
                      'video': 'http://50.7.164.234:8182/oworwldj5su4tqukwzdlnsrql2p47t2elhilugvo3txxvkxsnl7qdo5wk4/video.flv',
                      'genre': 'Gavin and Stacey Series 2'},
					                       {'name': 'Episode 4',
                      'thumb': 'http://cdn1.ssninsider.com/wp-content/uploads/2013/02/Gavin-And-Stacey-Series-2.jpg',
                      'video': 'http://50.7.164.226:8182/56oq2ilj5su4tqukwzdlnf3cdbndqr7zt2dk3ouedv56x3ru2xrtar3v6i/video.flv',
                      'genre': 'Gavin and Stacey Series 2'},
					                       {'name': 'Episode 5',
                      'thumb': 'http://cdn1.ssninsider.com/wp-content/uploads/2013/02/Gavin-And-Stacey-Series-2.jpg',
                      'video': 'http://50.7.164.234:8182/pkoryj3j5su4tqukwzdlnrzvlhtno42amyhlysyesdjtkgdycyr566bc5q/video.flv',
                      'genre': 'Gavin and Stacey Series 2'},
					                       {'name': 'Episode 6',
                      'thumb': 'http://cdn1.ssninsider.com/wp-content/uploads/2013/02/Gavin-And-Stacey-Series-2.jpg',
                      'video': 'http://50.7.164.202:8182/v2orijlj5su4tqukwzdlnrtndovv2z5r4dpqehw23gwlklnk2h6lf7lhpm/video.flv',
                      'genre': 'Gavin and Stacey Series 2'},
					                       {'name': 'Episode 7',
                      'thumb': 'http://cdn1.ssninsider.com/wp-content/uploads/2013/02/Gavin-And-Stacey-Series-2.jpg',
                      'video': 'http://50.7.164.234:8182/nworgjdj5su4tqukwzdlnfdki4jg42tud4uw3m2rjjnyfdr4rxwtbbal6e/video.flv',
                      'genre': 'Gavin and Stacey Series 2'},
					  {'name': 'Christmas Special',
                      'thumb': 'http://cdn1.ssninsider.com/wp-content/uploads/2013/02/Gavin-And-Stacey-Series-2.jpg',
                      'video': 'https://d5988.thevideo.me:8777/owjtbrzh7soammfvg6pvasm4oke6zoonrlkrn6w4jagxpgiiv5x53wxf5nyyhivrdvbbdso3dlsgexuqug5ug6dfav4c56otoqbmwphasxzgfnhaxtcyoqpkhq7g7l6cgjlrler4jrcie4hzg72qzaczvacvlivk57zwgb7uazhdp7igr7tyyvslfwjempov5vz6g7zk4nsdotbfyxdpbuccjbjhvp27dhvwo4dpku2cypl6q6weyfi22yvw2ozqfknflr2i/v.mp4',
                      'genre': 'Gavin and Stacey Series 2'}
					  ],
					  'Gavin and Stacey Series 3': [{'name': 'Episode 1',
                       'thumb': 'http://ilarge.lisimg.com/image/5359182/1000full-gavin-%26-stacey-poster.jpg',
                       'video': 'https://d0906.thevideo.me:8777/mojtaobg7soammfvg6pvaemrhlekagu5gnu2al3vzrtkg2zbr3znxdcojaqsyfe7nmu3kam3aypqe373t6sgga3a5lchhu7eezuzz4vbmsok6mmfkdwqgzzzxrujwfrinuusf65hivvwejh33uh56qan3jixllgb3eyfdklbhjyxt5dunbvykgbyvicgoonaspk3xl32uyjs3owwuc6xogr2opuwopzsw7ggzyh56zgqqy7cnuxgr2me2mm343ygutevrojo/v.mp4',
                       'genre': 'Gavin and Stacey Series 3'},
                     {'name': 'Episode 2',
                      'thumb': 'http://ilarge.lisimg.com/image/5359182/1000full-gavin-%26-stacey-poster.jpg',
                      'video': 'http://50.7.164.186:8182/lgorwwdj5su4tqukwzdlnh3kjuwfebt6owmrnyidsmywcvyuyiian2ifyy/video.flv',
                      'genre': 'Gavin and Stacey Series 3'},
                     {'name': 'Episode 3',
                      'thumb': 'http://ilarge.lisimg.com/image/5359182/1000full-gavin-%26-stacey-poster.jpg',
                      'video': 'https://d2787.thevideo.me:8777/msjtapbg7soammfvg6pvasuooee3gqh7zw45lyceescz6q7zzo5o3wwrvffslmg5wolktjd3aancg7sdfutpx3ugoznwysambnzyipj4ltq44gadnrbwblx4y46nvliydom27vhvnumlxhv2syzhysa33u2zicewuwiecmyi54j2pxkqf2ak5nss24oe247w2lk4nbgx3pnq7f5li223r3xg3lu5z5wfgvdjhwshvkgvrfxfldcoclblmjpv2jog67olcfcv/v.mp4',
                      'genre': 'Gavin and Stacey Series 3'},
                     {'name': 'Episode 4',
                      'thumb': 'http://ilarge.lisimg.com/image/5359182/1000full-gavin-%26-stacey-poster.jpg',
                      'video': 'https://d8584.thevideo.me:8777/osjtaprg7soammfvg6pvaauted4m3h6gikcw357dunusiq4x622564o2q7a4f2lda2ro5lxkxsmd3rl7xk3uuyn6ctajhsfks67rzxbifmfzkus5hadbgups7te6pmkc5ils2olfzcehcqgq7unsvrekacydg54no3cx75rkrvfimsrgpwq5uu5kvhspwkqmr5cwco2vojpn2jneq5aqd3uyzp2ediytyr6cddfxba7akbdpgys5fhnwcq755fck7pbab62n/v.mp4',
                      'genre': 'Gavin and Stacey Series 3'},
                     {'name': 'Episode 5',
                      'thumb': 'http://ilarge.lisimg.com/image/5359182/1000full-gavin-%26-stacey-poster.jpg',
                      'video': 'http://50.7.164.234:8182/oworwldj5su4tqukwzdlnsrql2p47t2elhilugvo3txxvkxsnl7qdo5wk4/video.flv',
                      'genre': 'Gavin and Stacey Series 3'},
                     {'name': 'Episode 6',
                      'thumb': 'http://ilarge.lisimg.com/image/5359182/1000full-gavin-%26-stacey-poster.jpg',
                      'video': 'http://50.7.164.234:8182/oworwldj5su4tqukwzdlnsrql2p47t2elhilugvo3txxvkxsnl7qdo5wk4/video.flv',
                      'genre': 'Gavin and Stacey Series 3'}
                     ]}


def get_categories():
    """
    Get the list of video categories.
    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.

    :return: list
    """
    return VIDEOS.keys()


def get_videos(category):
    """
    Get the list of videofiles/streams.
    Here you can insert some parsing code that retrieves
    the list of videostreams in a given category from some site or server.

    :param category: str
    :return: list
    """
    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Get video categories
    categories = get_categories()
    # Create a list for our items.
    listing = []
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category, thumbnailImage=VIDEOS[category][0]['thumb'])
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
                          'icon': VIDEOS[category][0]['thumb'],
                          'fanart': VIDEOS[category][0]['thumb']})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # http://mirrors.xbmc.org/docs/python-docs/15.x-isengard/xbmcgui.html#ListItem-setInfo
        list_item.setInfo('video', {'title': category, 'genre': category})
        # Create a URL for the plugin recursive callback.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = '{0}?action=listing&category={1}'.format(_url, category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the listing as a 3-element tuple.
        listing.append((url, list_item, is_folder))
    # Add our listing to Kodi.
    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
    # instead of adding one by ove via addDirectoryItem.
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: str
    """
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Create a list for our items.
    listing = []
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        list_item.setInfo('video', {'title': video['name'], 'genre': video['genre']})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for the plugin recursive callback.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/vids/crab.mp4
        url = '{0}?action=play&video={1}'.format(_url, video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the listing as a 3-element tuple.
        listing.append((url, list_item, is_folder))
    # Add our listing to Kodi.
    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
    # instead of adding one by ove via addDirectoryItem.
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
